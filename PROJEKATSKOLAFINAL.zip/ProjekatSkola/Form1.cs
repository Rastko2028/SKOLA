﻿using System.Diagnostics;

namespace ProjekatSkola
{
    public partial class Form1 : Form
    {
        private const int M = 16;
        private const int N = 16;
        private const int MINES = 40;
        private int cellSize = Math.Min(600 / N, 600 / M);
        private bool gameover = false;
        private int minesrem = 40;
        private int found = 0;
        private bool[,] BOARD = new bool[M, N];
        private bool[,] TEMPBOARD = new bool[M + 2, N + 2];
        private int[,] PRE = new int[M, N];
        private bool[,] moves = new bool[M, N];
        private bool[,] flags = new bool[M, N];

        public Form1()
        {
            InitializeComponent();
            InitBoard();
            this.ClientSize = new Size(cellSize * M + 200, cellSize * N);
        }

        private void InitBoard()
        {
            Random rand = new Random();
            List<int> a = new List<int>();
            for (int i = 0; i < M * N; i++)
                a.Add(i);
            for (int c = 0; c < MINES; c++)
            {
                int pos = rand.Next(a.Count - c);
                int row = a[pos] / N;
                int col = a[pos] % N;
                BOARD[row, col] = true;
                (a[pos], a[a.Count - 1 - c]) = (a[a.Count - 1 - c], a[pos]);
            }
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    TEMPBOARD[i + 1, j + 1] = BOARD[i, j];
                }
            }
            for (int i = 1; i <= M; i++)
            {
                for (int j = 1; j <= N; j++)
                {
                    if (TEMPBOARD[i, j]) PRE[i - 1, j - 1] = 9;
                    else
                    {
                        int ar = 0;
                        for (int k = -1; k <= 1; k++)
                        {
                            for (int m = -1; m <= 1; m++)
                            {
                                if (k == 0 && m == 0) continue;
                                if (TEMPBOARD[i + k, j + m]) ar++;
                            }
                        }
                        PRE[i - 1, j - 1] = ar;
                    }
                }
            }
        }

        private void RevealDFS(int r, int c)
        {
            if (r < 0 || r >= M || c < 0 || c >= N || moves[r, c] || flags[r, c])
                return;

            moves[r, c] = true;
            found++;
            if (PRE[r, c] == 0)
            {
                for (int dr = -1; dr <= 1; dr++)
                {
                    for (int dc = -1; dc <= 1; dc++)
                    {
                        if (dr == 0 && dc == 0) continue;
                        RevealDFS(r + dr, c + dc);
                    }
                }
            }
        }

        private void RevealAround(int row, int col)
        {
            for (int dr = -1; dr <= 1; dr++)
            {
                for (int dc = -1; dc <= 1; dc++)
                {
                    int r = row + dr;
                    int c = col + dc;
                    if (r >= 0 && r < M && c >= 0 && c < N && !moves[r, c] && !flags[r, c])
                    {
                        if (BOARD[r, c])
                        {
                            gameover = true;
                        }
                        else
                        {
                            RevealDFS(r, c);
                        }
                    }
                }
            }
        }

        private int CountFlagsAround(int row, int col)
        {
            int count = 0;
            for (int dr = -1; dr <= 1; dr++)
            {
                for (int dc = -1; dc <= 1; dc++)
                {
                    int r = row + dr;
                    int c = col + dc;
                    if (r >= 0 && r < M && c >= 0 && c < N && flags[r, c])
                        count++;
                }
            }
            return count;
        }

        protected override void OnMouseDoubleClick(MouseEventArgs e)
        {
            base.OnMouseDoubleClick(e);
            int x = e.X / cellSize;
            int y = e.Y / cellSize;
            if (x < 0 || x >= N || y < 0 || y >= M || !moves[y, x] || PRE[y, x] <= 0 || PRE[y, x] >= 9) return;

            if (CountFlagsAround(y, x) == PRE[y, x])
            {
                RevealAround(y, x);
                Invalidate();
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Font emojiFont = new Font("Segoe UI Emoji", cellSize / 2);
            Font infoFont = new Font("Font", 14, FontStyle.Bold);
            g.DrawString(minesrem.ToString(), infoFont, Brushes.Black, M * cellSize + 40, 25);
            for (int r = 0; r < M; r++)
            {
                for (int c = 0; c < N; c++)
                {
                    int x = c * cellSize;
                    int y = r * cellSize;
                    g.DrawRectangle(Pens.Black, x, y, cellSize, cellSize);
                    if (moves[r, c] && PRE[r, c] == 9)
                    {
                        gameover = true;
                        string message = "GAME OVER";
                        Font messageFont = new Font("Arial", 20, FontStyle.Bold);
                        g.DrawString(message, messageFont, Brushes.Red, M * cellSize + 10, N * cellSize - 30);
                    }
                    else if (found == M * N - MINES)
                    {
                        gameover = true;
                        string message = "GAME WON";
                        Font messageFont = new Font("Arial", 20, FontStyle.Bold);
                        g.DrawString(message, messageFont, Brushes.Red, M * cellSize + 10, N * cellSize - 30);
                    }
                    else if (moves[r, c])
                    {
                        g.DrawString(PRE[r, c].ToString(), this.Font, Brushes.Black, x + 10, y + 8);
                    }
                    else if (flags[r, c])
                    {
                        g.DrawString("🚩", emojiFont, Brushes.Red, x, y + 2);
                    }
                }
            }
            if (gameover)
            {
                for (int r = 0; r < M; r++)
                {
                    for (int c = 0; c < N; c++)
                    {
                        int x = c * cellSize;
                        int y = r * cellSize;
                        if (PRE[r, c] == 9 && !flags[r, c])
                        {
                            g.DrawString("💣", emojiFont, Brushes.Red, x, y + 2);
                        }
                        else if (flags[r, c])
                        {
                            g.DrawString("🚩", emojiFont, Brushes.Red, x, y + 2);
                        }
                        else if (PRE[r, c] != 9)
                        {
                            g.DrawString(PRE[r, c].ToString(), this.Font, Brushes.Black, x + 10, y + 8);
                        }
                    }
                }
            }
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            int x = e.X / cellSize;
            int y = e.Y / cellSize;
            if (x < 0 || x >= N || y < 0 || y >= M) return;

            if (e.Button == MouseButtons.Left && !moves[y, x] && !gameover && !flags[y, x])
            {
                RevealDFS(y, x);
                Invalidate();
            }
            else if (e.Button == MouseButtons.Right && !gameover)
            {
                if (flags[y, x])
                {
                    minesrem++;
                    flags[y, x] = false;
                }
                else if (!flags[y, x] && minesrem > 0)
                {
                    minesrem--;
                    flags[y, x] = true;
                }
                Invalidate();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
